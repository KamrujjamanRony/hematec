export const environment = {
    production: false,
    authKey: "0",
    companyCode: 3,
    location: 'Lane 30, Fu de, 3 Road, Xizhi dist, Taipei city, Taiwan',
    ProductApi: 'https://mec.supersoftbd.com/apiA/Product',
    CarouselApi: 'https://mec.supersoftbd.com/apiA/Carousel',
    AboutApi: 'https://mec.supersoftbd.com/apiA/AboutUs',
    ContactApi: 'https://mec.supersoftbd.com/apiA/Address',
    ImageApi: 'https://mec.supersoftbd.com/Images/',
    emptyImg: 'https://www.mykite.in/kb/NoImageFound.jpg.png',
};