export interface UpdateAboutRequest {
    CompanyID: number;
    heading: string,
    title: string,
    description: string,
    title2: string,
    description2: string,
    title3: string,
    description3: string,
    title4: string,
    description4: string,
    title5: string;
    description5: string;
}